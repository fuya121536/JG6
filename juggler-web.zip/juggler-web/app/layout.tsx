import './globals.css'

export const metadata = {
  title: 'Juggler Analyzer',
  description: 'Juggler 設定判別 & 翌日予測'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#000000" />
      </head>
      <body>{children}</body>
    </html>
  )
}
