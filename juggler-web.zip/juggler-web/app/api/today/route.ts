import { NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

export const revalidate = 60

export async function GET() {
  const today = new Date().toISOString().slice(0,10)
  const { data, error } = await supabase
    .from('juggler_history')
    .select('*')
    .eq('date', today)
    .order('expect6', { ascending: false })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data ?? [])
}
