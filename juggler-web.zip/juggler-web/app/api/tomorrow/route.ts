import { NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

export const revalidate = 300

export async function GET() {
  // 簡易版: 直近7日間の平均 expect6 をベースに tomorrow_expect を計算
  const since = new Date(Date.now() - 7*24*3600*1000).toISOString().slice(0,10)
  const { data, error } = await supabase
    .from('juggler_history')
    .select('machine,number,expect6,date')
    .gte('date', since)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  const key = (r: any) => `${r.machine}-${r.number}`
  const map = new Map<string, { machine: string, number: number, values: number[] }>()
  for (const r of (data ?? [])) {
    const k = key(r)
    if (!map.has(k)) map.set(k, { machine: r.machine, number: r.number, values: [] })
    map.get(k)!.values.push(r.expect6 ?? 0)
  }

  const result = Array.from(map.values()).map(v => {
    const avg = v.values.reduce((a,b)=>a+b,0) / v.values.length
    const tomorrow_expect = Math.min(1, Math.max(0, avg * 1.1)) // 適当な係数
    return { ...v, tomorrow_expect }
  }).sort((a,b)=> b.tomorrow_expect - a.tomorrow_expect)

  return NextResponse.json(result)
}
