'use client'
import useSWR from 'swr'
import { List, Tag } from 'antd-mobile'

const fetcher = (url: string) => fetch(url).then(r => r.json())

export default function Page() {
  const { data, error } = useSWR('/api/today', fetcher, { refreshInterval: 60_000 })

  if (error) return <p style={{padding:16}}>読み込みエラー: {String(error)}</p>
  if (!data)  return <p style={{padding:16}}>Loading...</p>

  return (
    <div>
      <h1 style={{padding:"12px 16px"}}>本日の設定判別</h1>
      <List>
        {data.map((r:any) => (
          <List.Item
            key={`${r.machine}-${r.number}`}
            title={`${r.machine} 台${r.number}`}
            description={`BIG ${r.big} / REG ${r.reg} / 回転 ${r.spins.toLocaleString()}`}
            extra={<Tag color='success'>{Math.round((r.expect6 ?? 0)*100)}%</Tag>}
          />
        ))}
      </List>
    </div>
  )
}
