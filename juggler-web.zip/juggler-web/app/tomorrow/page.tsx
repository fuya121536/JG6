'use client'
import useSWR from 'swr'
import { List, Tag } from 'antd-mobile'

const fetcher = (url: string) => fetch(url).then(r => r.json())

export default function Tomorrow() {
  const { data, error } = useSWR('/api/tomorrow', fetcher)

  if (error) return <p style={{padding:16}}>error: {String(error)}</p>
  if (!data)  return <p style={{padding:16}}>Loading...</p>

  return (
    <div>
      <h1 style={{padding:"12px 16px"}}>明日の設定6期待度ランキング</h1>
      <List>
        {data.map((r:any) => (
          <List.Item
            key={`${r.machine}-${r.number}`}
            title={`${r.machine} 台${r.number}`}
            extra={<Tag color='primary'>{Math.round((r.tomorrow_expect ?? 0)*100)}%</Tag>}
          />
        ))}
      </List>
    </div>
  )
}
